# Poker AI Agent

An autonomous agent for six-player no-limit holdem.

## Use of a Virtual Machine

You must use a Windows virtual machine in VirtualBox. Follow the steps in [this article](https://www.freecodecamp.org/news/what-is-a-virtual-machine-and-how-to-setup-a-vm-on-windows-linux-and-mac) to set one up. The host machine should ideally also be Windows. Nothing is guaranteed to work on other systems.

## Environment Setup

Use the following steps to set up the agent:

* Create a Python 3.10 virtual environment in the root directory.
* Run the command `pip install -r requirements.txt`
* Follow the instruction in [this repo](https://github.com/livezingy/tesserocr_python310) to install tesserocr.
* A ZenithPoker account is needed. Create a file `config/zenith-login-cookies.txt` and paste the cookies copied from the network tab in the browser.
* A GTOWizard account is needed. Create a file `config/zenith-tokens.json` in the form `{"access_token": "TOKEN", "refresh_token": TOKEN}`. The tokens can be obtained from the `localStorage` object in the browser.
* Create a file `config/wizard-tokens.json` in the form `{"access": "TOKEN", "refresh": "TOKEN"}` using the same method.

## Table Setup

Install PokerStars on the guest machine and open a table. Then run `src/bot/table_setup.py` on the host machine and follow the instructions to set up the bounding boxes for the table.

# Running the Agent

Run the agent with `python src/main.py` with a game window open. The game window must be visible at all times. Ensure that keyboard input is being sent to the guest machine.
